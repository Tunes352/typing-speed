from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "neurosense.db"

app = Flask(__name__)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS enquiries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/api/enquiries")
def create_enquiry():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    subject = str(data.get("subject", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or not email or not message:
        return jsonify({"error": "Name, email and message are required."}), 400

    if "@" not in email or len(email) > 254:
        return jsonify({"error": "Please enter a valid email address."}), 400

    if len(name) > 120 or len(subject) > 200 or len(message) > 5000:
        return jsonify({"error": "One or more fields are too long."}), 400

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """INSERT INTO enquiries
               (name, email, subject, message, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (name, email, subject, message,
             datetime.now(timezone.utc).isoformat())
        )
        conn.commit()

    return jsonify({"success": True, "message": "Enquiry received."}), 201

@app.get("/health")
def health():
    return jsonify({"status": "ok", "service": "NeuroSense backend"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
else:
    init_db()
